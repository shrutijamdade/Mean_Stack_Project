import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgetp',
  templateUrl: './forgetp.component.html',
  styleUrls: ['./forgetp.component.css']
})
export class ForgetpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
